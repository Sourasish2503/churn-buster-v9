// app/page.tsx
export default function Home() {
  return (
    <div className="flex h-screen items-center justify-center bg-black text-white">
      <p>Please open this app from the Whop Dashboard.</p>
    </div>
  );
}